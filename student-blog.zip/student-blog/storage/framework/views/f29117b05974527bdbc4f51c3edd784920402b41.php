
<link rel="stylesheet" href="<?php echo e(asset('frontend/css/chat.css')); ?>">
<!------ Include the above in your HEAD tag ---------->

<?php $__env->startSection('content'); ?>
<div class="container mt-3">
    <div class="row">
          <div class="col-md-8 mx-auto">
              <div class="card">
                  <div class="card-header text-center">
                      <span>Chat with <?php echo e($receiver_user->name); ?></span>
                  </div>
                  <div class="card-body chat-body chat-care">
                      <ul class="chat">

                          <?php if($chat): ?>
                          <?php $__currentLoopData = \App\ChatMessage::where('chat_id', $chat->id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chatmessage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php
                              $sender = \App\User::where('id', $chatmessage->sender_id)->first();
                              $receiver = \App\User::where('id', $chatmessage->reciver_id)->first();
                          ?>
                          <?php if($chatmessage->sender_id == Auth::user()->id): ?>
                          <li class="admin clearfix">
                            <span class="chat-img right clearfix  mx-2">
                                <img src="http://placehold.it/50/FA6F57/fff&text=ME" alt="Admin" class="img-circle" />
                            </span>
                            <div class="chat-body clearfix">
                                <div class="header clearfix">
                                    <small class="left text-muted"><span class="glyphicon glyphicon-time"></span><?php echo e(Carbon\Carbon::parse($chatmessage->created_at)->diffForHumans()); ?> 
                                    </small>
                                    <strong class="right primary-font"><?php echo e($sender->name); ?></strong>
                                </div>
                                <p>
                                    <?php echo e($chatmessage->message); ?>

                                </p>
                            </div>
                        </li>
                            <?php else: ?> 
                            <li class="agent clearfix">
                                <span class="chat-img left clearfix mx-2">
                                    <img src="http://placehold.it/50/55C1E7/fff&text=U" alt="Agent" class="img-circle" />
                                </span>
                                <div class="chat-body clearfix">
                                    <div class="header clearfix">
                                        <strong class="primary-font"><?php echo e($receiver->name); ?></strong> <small class="right text-muted">
                                            <span class="glyphicon glyphicon-time"></span><?php echo e(Carbon\Carbon::parse($chatmessage->created_at)->diffForHumans()); ?> </small>
                                    </div>
                                    <p>
                                        <?php echo e($chatmessage->message); ?>

                                    </p>
                                </div>
                            </li>
                            <?php endif; ?>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          <?php endif; ?>
                         
                         
                      </ul>
                  </div>
                  <div class="card-footer">
                      <form action="<?php echo e(route('chat.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="input-group">
                            <input id="btn-input" type="text" name="message" class="form-control input-sm" placeholder="Type your message here..." />
                            <input type="hidden" name="reciver_id" value="<?php echo e($receiver_user->id); ?>">
                            <span class="input-group-btn">
                                <button type="submit" class="btn btn-primary" id="btn-chat">
                                    Send</button>
                            </span>
                        </div>
                      </form>
                  </div>
              </div>
          </div>
      </div>
  </div>



<?php $__env->stopSection(); ?>


<?php $__env->startSection('frontend_script'); ?>
<script>
    $('.chat-body').scrollTop(1000000);
</script>    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project\student-blog\resources\views/chat.blade.php ENDPATH**/ ?>