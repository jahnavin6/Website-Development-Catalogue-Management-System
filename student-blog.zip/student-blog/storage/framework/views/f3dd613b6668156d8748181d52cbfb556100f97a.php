

<?php $__env->startSection('content'); ?>
<div class="about-area">
    
    <div class="main-content about-main-content mt-2">
        <div class="row">
            <div class="col-md-8 offset-md-2">
                <h3 class="mt-4 text-center">All Enrolled course for <?php echo e(Auth::user()->name); ?></h3>
                <div class="home-department-list mt-5">
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <tr>
                                <th>Id</th>
                                <th>Name</th>
                                <th>Instructor email</th>
                                <th>Department</th>
                            </tr>
                            <?php $__currentLoopData = $enrolled_course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($item->course->course_id); ?></td>
                                    <td><?php echo e($item->course->name); ?></td>
                                    <td><?php echo e($item->course->inst_email); ?></td>
                                    <td><?php echo e($item->course->department); ?></td>
                                  
                                </tr>  
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project\student-blog\resources\views/student/enrolled_course.blade.php ENDPATH**/ ?>