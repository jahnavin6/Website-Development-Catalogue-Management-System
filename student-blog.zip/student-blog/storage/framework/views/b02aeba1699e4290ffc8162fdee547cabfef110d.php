<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('frontend/css/style.css')); ?>">
    <title>User panel!</title>
  </head>
  <body>
    <header class="header-area">
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
           <div class="container">
            <a class="navbar-brand" href="<?php echo e(route('home_page')); ?>">
                <img src="<?php echo e(asset('frontend/images/student.png')); ?>" style="width: 50px" alt="">
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon"></span>
            </button>
          
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
              <ul class="navbar-nav ml-auto">
                <li class="nav-item active">
                  <a class="nav-link" href="<?php echo e(route('home_page')); ?>">Home</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="<?php echo e(route('about')); ?>">About</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" target="_blank" href="https://jxn7251.uta.cloud/">Forum</a>
                </li>
                <?php if(Auth::check() && Auth::user()->role == 'student'): ?>
                <li class="nav-item">
                  <a class="nav-link" href="<?php echo e(route('all.course')); ?>">List of Courses</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="<?php echo e(route('provide_feedback')); ?>">Provide Feedback</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="<?php echo e(route('teacher.list')); ?>">Chat</a>
                </li>
               
                <li class="nav-item">
                  <a class="nav-link" href="<?php echo e(route('enrolled_course')); ?>">Enrolled Courses</a>
                </li>
                
                <?php endif; ?>
               
                <li class="nav-item pt-1">
                    <?php if(auth()->guard()->check()): ?>
                    <a href="href="<?php echo e(route('logout')); ?>"" class="btn btn-danger btn-sm rounded-0 ml-1" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">logout</a>
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                        <?php echo csrf_field(); ?>
                    </form>
                        <?php else: ?>
                        <div class="btn-group" role="group" aria-label="Basic example">
                            <a href="<?php echo e(route('register')); ?>" class="btn btn-success btn-sm rounded-0">SIGN Up</a>
                            <a href="<?php echo e(route('login')); ?>" class="btn btn-secondary btn-sm rounded-0 ml-1">Login</a>
                        </div>
                    <?php endif; ?>
                </li>
              </ul>
            </div>
           </div>
          </nav>
    </header>

    <div class="main-area">
        <?php echo $__env->yieldContent('content'); ?>
    </div>

    <footer class="footer-area">
       <div class="container">
        <div class="row">
            <div class="col-md-6">
                <p>&copy; Copyrights reserved | Created by Jahnavi Nuthalapati</p>
            </div>
            <div class="col-md-6">
                <div class="footer-social">
                    <ul>
                        <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                        <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                        <li><a href="#"><i class="fa fa-reddit"></i></a></li>
                        <li><a href="#"><i class="fa fa-youtube"></i></a></li>
                        <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                    </ul>
                </div>
            </div>
        </div>
       </div>
    </footer>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js"></script>
  <?php echo $__env->yieldContent('frontend_script'); ?>
  </body>
</html><?php /**PATH C:\xampp\htdocs\project\student-blog\resources\views/layouts/frontend/layout.blade.php ENDPATH**/ ?>