

<?php $__env->startSection('content'); ?>
    <div class="main-content about-main-content mt-5">
        <div class="container">
            <div class="card">
                <div class="card-header d-flex justify-content-between">
                    <h5 class="">Planned courses</h5>
                    <a href="<?php echo e(route('course.create')); ?>" class="btn btn-primary">Add course</a>
                </div>
                <div class="card-body">
                    <?php if(session()->has('success')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session()->get('success')); ?>

                    </div>
                <?php endif; ?>
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <tr>
                                <th>Id</th>
                                <th>Name</th>
                                <th>Instructor email</th>
                                <th>Department</th>
                                <th>status</th>
                                <th>Image</th>
                                <th>Action</th>
                            </tr>
                            <?php $__currentLoopData = $planned_course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($item->course_id); ?></td>
                                    <td><?php echo e($item->name); ?></td>
                                    <td><?php echo e($item->inst_email); ?></td>
                                    <td><?php echo e($item->department); ?></td>
                                    <td><?php echo e($item->status); ?></td>
                                    <td>
                                        <img src="<?php echo e('/storage/'.$item->image); ?>" alt="image" style="width: 50px">
                                    </td>
                                    <td>
                                        <div class="btn-group" role="group" aria-label="Basic example">
                                            <form action="<?php echo e(route('course.destroy', $item->id)); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                                            </form>
                                          </div>
                                    </td>
                                </tr>  
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.staff.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project\student-blog\resources\views/staff/planned_course.blade.php ENDPATH**/ ?>