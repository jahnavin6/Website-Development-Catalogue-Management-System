

<?php $__env->startSection('content'); ?>
    <div class="main-content about-main-content mt-5">
        <div class="container">
            <div class="card">
                <div class="card-header">
                    <h5 class="text-center">All feedback</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <tr>
                                <th>SI</th>
                                <th>Course name</th>
                                <th>Instractor email</th>
                                <th>Student name</th>
                                <th>Feedback</th>
                            </tr>
                            <?php
                                $i=0;
                            ?>
                            <?php $__currentLoopData = $feedbacks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $i++;
                            ?>
                                <tr>
                                    <td><?php echo e($i); ?></td>
                                    <td><?php echo e($item->course->name); ?></td>
                                    <td><?php echo e($item->course->inst_email); ?></td>
                                    <td><?php echo e($item->user->name); ?></td>
                                    <td><?php echo e($item->feedback); ?></td>
                                   
                                </tr>  
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.staff.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project\student-blog\resources\views/staff/view_feedback.blade.php ENDPATH**/ ?>