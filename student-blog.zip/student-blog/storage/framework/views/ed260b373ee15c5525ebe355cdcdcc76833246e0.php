

<?php $__env->startSection('content'); ?>
<div class="about-area">
    <div class="page-banner about-page-banenr">
        <h1 class="text-center">About</h1>
    </div>
    <div class="main-content about-main-content text-center mt-5">
        <div class="container">
            <h3 class="m-4">SUCCEED BY SAVING TIME </h3>
            <p>At CMS, we believe that learning is the world's most powerful force for change.The platform helps students, faculty to save time, increase productivity among everything.
            </p>
            <p>
                Developed in such a way that student will be able to select the courses from the given list and enroll.
            </p>
            <h3 class="m-4">STUDY.ACHIEVE.EXCEL
            </h3>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project\student-blog\resources\views/admin_about.blade.php ENDPATH**/ ?>