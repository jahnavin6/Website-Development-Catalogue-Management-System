

<?php $__env->startSection('content'); ?>
    <div class="main-content about-main-content mt-5">
        <div class="container">
            <div class="card">
                <div class="card-header">
                    <h5 class="text-center">All users</h5>
                </div>
                <div class="card-body">
                    <?php if(session()->has('success')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session()->get('success')); ?>

                    </div>
                <?php endif; ?>
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <tr>
                                <th>Sl</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>User type</th>
                                <th>Action</th>
                            </tr>
                            <?php
                                $i=0;
                            ?>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $i++;
                            ?>
                                <tr>
                                    <td><?php echo e($i); ?></td>
                                    <td><?php echo e($user->name); ?></td>
                                    <td><?php echo e($user->email); ?></td>
                                    <td><?php echo e($user->role); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('admin.delete.users',$user->id)); ?>" class="btn btn-danger btn-sm">Delete</a>
                                    </td>
                                </tr>  
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project\student-blog\resources\views/admin/users.blade.php ENDPATH**/ ?>