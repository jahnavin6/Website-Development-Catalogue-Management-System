

<?php $__env->startSection('content'); ?>
<div class="about-area">
    
    <div class="main-content about-main-content mt-5">
        <div class="row">
            <div class="col-md-8 offset-md-2">
                <h3 class="mt-4">All courses</h3>
                <div class="home-department-list mt-5">
                    <?php if(session()->has('success')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session()->get('success')); ?>

                    </div>
                <?php endif; ?>
                <?php if(session()->has('failed')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session()->get('failed')); ?>

                    </div>
                <?php endif; ?>
                    <div class="row">
                        <?php $__currentLoopData = \App\Course::orderBy('id', 'desc')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-4 mb-2">
                            <div class="single-department">
                                 <div class="card m-9 p-0">
                                     <div class="card-body m-0 p-0">
                                         <div class="department-image">
                                             <img src="<?php echo e('/storage/'.$course->image); ?>" alt="" width="100%">
                                         </div>
                                         <div class="department-content text-center pt-2 pb-2">
                                            <a href="" class="text-decoration-none"><?php echo e($course->name); ?></a>
                                            <div class="course-information-area text-left">
                                                <p><b>Department</b>  : <?php echo e($course->department); ?></p>
                                                <p><b>Ins. email</b>  : <?php echo e($course->inst_email); ?></p>
                                            </div>
                                                <?php
                                                if(Auth::check()) {
                                                    $check_enrole = \App\Enroll::where('course_id', $course->id)->where('user_id',Auth::user()->id)->count();
                                                }else {
                                                    $check_enrole = 0;
                                                }
                                                    
                                                ?>
                                           
                                             <?php if($check_enrole > 0): ?>
                                            
                                                <button class="btn btn-danger btn-block" disabled>Already enroled</button>
                                                <?php else: ?>
                                                <a href="<?php echo e(route('course.enrole', $course->id)); ?>" class="btn btn-primary btn-block mt-2">Enroll</a>
                                             <?php endif; ?>
                                         </div>
                                     </div>
                                 </div>
                            </div>
                         </div> 
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project\student-blog\resources\views/courses.blade.php ENDPATH**/ ?>