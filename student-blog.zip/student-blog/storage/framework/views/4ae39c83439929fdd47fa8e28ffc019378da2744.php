

<?php $__env->startSection('content'); ?>
<div class="about-area">
    
    <div class="main-content about-main-content mt-2">
        <div class="row">
            <div class="col-md-8 offset-md-2">
                <h3 class="mt-4 text-center">Teachers list</h3>
                <div class="home-department-list mt-5">
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <tr>
                                <th>SI</th>
                                <th>Name</th>
                                <th>email</th>
                                <th>Chat</th>
                            </tr>
                            <?php
                                $i=0;
                            ?>
                            <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $i++;
                            ?>
                                <tr>
                                    <td><?php echo e($i); ?></td>
                                    <td><?php echo e($teacher->name); ?></td>
                                    <td><?php echo e($teacher->email); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('single.chat', $teacher->id)); ?>" class="btn btn-sm btn-primary">Chat</a>
                                    </td>
                                </tr>  
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project\student-blog\resources\views/student/tacher_list.blade.php ENDPATH**/ ?>