

<?php $__env->startSection('content'); ?>
    <div class="main-content about-main-content mt-5">
        <div class="row justify-content-center">
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header text-center"><h3><?php echo e(__('Give a feedback')); ?></h3></div>
    
                    <div class="card-body">
                        <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                        <?php if(session()->has('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session()->get('success')); ?>

                        </div>
                    <?php endif; ?>
                    <?php if(session()->has('failed')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session()->get('failed')); ?>

                        </div>
                    <?php endif; ?>
                        <form method="POST" action="<?php echo e(route('feedback.store')); ?>">
                            <?php echo csrf_field(); ?>
    
                            <div class="form-group">
                                <label>Select a course</label>
                                <select name="course_id" class="form-control">
                                    <option selected disabled>Select a course</option>
                                    <?php $__currentLoopData = $enroll_courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->course->id); ?>"><?php echo e($item->course->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Feedback</label>
                                <textarea name="feedback" class="form-control" placeholder="Type your feedback here"></textarea>
                            </div>
                            <div class="form-group">
                                <button type="submit" class="btn btn-primary btn-block">Save</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project\student-blog\resources\views/give_feedback.blade.php ENDPATH**/ ?>