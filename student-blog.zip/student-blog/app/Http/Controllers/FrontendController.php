<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class FrontendController extends Controller
{
    public function index()
    {
        return view('welcome');
    }
    public function about()
    {
        return view('about');
    }
    public function admin_about()
    {
        return view('admin_about');
    }
    public function staff_about()
    {
        return view('staff_about');
    }
    public function student_about()
    {
        return view('student_about');
    }
}
