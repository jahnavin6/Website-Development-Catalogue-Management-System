<?php

namespace App\Http\Controllers;

use App\User;
use Illuminate\Http\Request;

class StaffController extends Controller
{
    public function index()
    {
        return view('staff.index');
    }

    public function student_list()
    {
        $students = User::where('role','student')->get();
        return view('staff.student_list', compact('students'));
    }
    // public function add_course()
    // {
    //     return view()
    // }
}
