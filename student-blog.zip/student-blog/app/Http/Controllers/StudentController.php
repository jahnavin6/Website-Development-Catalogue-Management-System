<?php

namespace App\Http\Controllers;

use App\Course;
use App\Enroll;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class StudentController extends Controller
{
    public function index()
    {
        $courses = Course::orderBy('id','desc')->get();
        return view('student.index' , compact('courses'));
    }
    public function courses()
    {
        $courses = Course::orderBy('id','desc')->get();
        return view('courses' , compact('courses'));
    }
    public function enroll_courses($id)
    {
        $enroll = new Enroll();
        $enroll->user_id = Auth::user()->id;
        $enroll->course_id = $id;

        if($enroll->save()){
            return back()->with('success', 'Your enrole this course successfully');
        }else {
            return back()->with('failed', 'Faile to enroll. please try again');
        }
    }
    public function enrolled_course()
    {
        $enrolled_course = Enroll::where('user_id', Auth::user()->id)->get();

        return view('student.enrolled_course', compact('enrolled_course'));
    }
    public function provide_feedback()
    {
        $enroll_courses = Enroll::where('user_id', Auth::user()->id)->get();
        return view('give_feedback',compact('enroll_courses'));
    }
    public function tacher_list()
    {
        $teachers = User::where('role','staff')->get();
        return view('student.tacher_list', compact('teachers'));
    }
}
