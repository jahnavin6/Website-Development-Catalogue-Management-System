<?php

namespace App\Http\Controllers;

use App\User;
use Illuminate\Http\Request;

class AdminController extends Controller
{
    public function index()
    {
        return view('admin.index');
    }
    public function users()
    {
        $users = User::orderBy('id','desc')->get();
        return view('admin.users', compact('users'));
    }

    public function delete_user($id)
    {
        $user = User::findOrFail($id);
        if ($user->delete()) {
            return back()->with('success', 'Data has been deleted successfully!');
        }
    }
}
