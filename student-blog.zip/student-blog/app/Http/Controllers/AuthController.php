<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;

class AuthController extends Controller
{
    public function login(Request $request)
    {
        request()->validate([
            'email' => 'required',
            'password' => 'required',
            ]);
    
            $credentials = $request->only('email', 'password');
            if (Auth::attempt($credentials)) {
                // Authentication passed...
                if(Auth::user()->role == 'admin') {
                    return redirect()->route('admin.home');
                }elseif(Auth::user()->role == 'staff') {
                    return redirect()->route('staff.home');
                }elseif(Auth::user()->role == 'student'){
                    return redirect()->route('student.home');
                }else {
                    return redirect()->to('/');
                }
                
            }
            return redirect()->to("login")->with('failed','Oppes! You have entered invalid credentials');
    }
}
