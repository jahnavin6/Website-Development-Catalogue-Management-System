<?php

namespace App\Http\Controllers;

use App\Chat;
use App\ChatMessage;
use Illuminate\Http\Request;

class ChatMessageController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // return $request;
        $checkChats1 = Chat::where('sender_id', auth()->user()->id)->where('receiver_id', $request->reciver_id)->first();
        $checkChats2 = Chat::where('sender_id', $request->reciver_id)->where('receiver_id', auth()->user()->id)->first();


      
        $data = [
            'sender_id' => auth()->user()->id,
            'reciver_id' => $request->reciver_id,
        ];
        if ($checkChats1) {
            $data['chat_id'] = $checkChats1->id;
        } elseif ($checkChats2) {
            $data['chat_id'] = $checkChats2->id;
        } 
        else {
            $chat = Chat::create([

                'sender_id' => auth()->user()->id,
                'receiver_id' => $request->reciver_id,
            ]);

            $data['chat_id'] = $chat->id;
        }
        $data['message'] = $request->message;

        $this->messageStore($data);
        return redirect()->back();
    }

    public function messageStore($data)
    {
        $chatMessage = ChatMessage::create([
            'sender_id' => $data['sender_id'],
            'reciver_id' => $data['reciver_id'],
            'message' => $data['message'],
            'chat_id' => $data['chat_id'],
        ]);
        return  $chatMessage;
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\ChatMessage  $chatMessage
     * @return \Illuminate\Http\Response
     */
    public function show(ChatMessage $chatMessage)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\ChatMessage  $chatMessage
     * @return \Illuminate\Http\Response
     */
    public function edit(ChatMessage $chatMessage)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\ChatMessage  $chatMessage
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ChatMessage $chatMessage)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\ChatMessage  $chatMessage
     * @return \Illuminate\Http\Response
     */
    public function destroy(ChatMessage $chatMessage)
    {
        //
    }
}
