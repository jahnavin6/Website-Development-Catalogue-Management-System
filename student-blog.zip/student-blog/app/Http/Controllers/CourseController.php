<?php

namespace App\Http\Controllers;

use App\Course;
use Illuminate\Http\Request;

class CourseController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        
    }
    public function planned_course()
    {
        $planned_course = Course::where('status', 'planned')->get();
        return view('staff.planned_course',compact('planned_course'));
    }
    public function upcoming_course()
    {
        $upcoming_course = Course::where('status', 'upcoming')->get();
        return view('staff.upcoming_couse',compact('upcoming_course'));
    }
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('staff.add_course');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // return $request->image;
        // $course = new Course();
        $data = $request->validate([
            'course_id' => 'required',
            'name' => 'required',
            'department' => 'required',
            // 'image' => 'required',
            'inst_email' => 'required',
            'status' => 'required',
        ]);
        if($request->hasFile('image')) {
          $data['image'] = $request->image->store('course', 'public');
        }

        if (Course::create($data)) {
            return back()->with('success', 'Course added successfully');
        } else {
            return back()->with('failed', 'Failed to add course');
        }


    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Course  $course
     * @return \Illuminate\Http\Response
     */
    public function show(Course $course)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Course  $course
     * @return \Illuminate\Http\Response
     */
    public function edit(Course $course)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Course  $course
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Course $course)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Course  $course
     * @return \Illuminate\Http\Response
     */
    public function destroy(Course $course)
    {
        $course = Course::findOrFail($course->id);
        if ($course->delete()) {
            return back()->with('success', 'Data has been deleted successfully!');
        }
    }
}
