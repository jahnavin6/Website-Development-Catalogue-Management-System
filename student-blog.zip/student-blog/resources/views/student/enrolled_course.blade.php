@extends('layouts.frontend.layout')

@section('content')
<div class="about-area">
    {{-- <div class="page-banner about-page-banenr">
        <h1 class="text-center">About</h1>
    </div> --}}
    <div class="main-content about-main-content mt-2">
        <div class="row">
            <div class="col-md-8 offset-md-2">
                <h3 class="mt-4 text-center">All Enrolled course for {{ Auth::user()->name }}</h3>
                <div class="home-department-list mt-5">
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <tr>
                                <th>Id</th>
                                <th>Name</th>
                                <th>Instructor email</th>
                                <th>Department</th>
                            </tr>
                            @foreach ($enrolled_course as $item)
                                <tr>
                                    <td>{{ $item->course->course_id }}</td>
                                    <td>{{ $item->course->name }}</td>
                                    <td>{{ $item->course->inst_email }}</td>
                                    <td>{{ $item->course->department }}</td>
                                  
                                </tr>  
                            @endforeach
                            
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
