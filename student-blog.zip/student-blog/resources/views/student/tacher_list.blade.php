@extends('layouts.frontend.layout')

@section('content')
<div class="about-area">
    {{-- <div class="page-banner about-page-banenr">
        <h1 class="text-center">About</h1>
    </div> --}}
    <div class="main-content about-main-content mt-2">
        <div class="row">
            <div class="col-md-8 offset-md-2">
                <h3 class="mt-4 text-center">Teachers list</h3>
                <div class="home-department-list mt-5">
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <tr>
                                <th>SI</th>
                                <th>Name</th>
                                <th>email</th>
                                <th>Chat</th>
                            </tr>
                            @php
                                $i=0;
                            @endphp
                            @foreach ($teachers as $teacher)
                            @php
                                $i++;
                            @endphp
                                <tr>
                                    <td>{{ $i }}</td>
                                    <td>{{ $teacher->name }}</td>
                                    <td>{{ $teacher->email }}</td>
                                    <td>
                                        <a href="{{ route('single.chat', $teacher->id) }}" class="btn btn-sm btn-primary">Chat</a>
                                    </td>
                                </tr>  
                            @endforeach
                            
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
