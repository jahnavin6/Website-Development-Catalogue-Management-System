@extends('layouts.staff.layout')

@section('content')
    <div class="main-content about-main-content mt-5">
        <div class="container">
            <div class="card">
                <div class="card-header d-flex justify-content-between">
                    <h5 class="">Planned courses</h5>
                    <a href="{{ route('course.create') }}" class="btn btn-primary">Add course</a>
                </div>
                <div class="card-body">
                    @if(session()->has('success'))
                    <div class="alert alert-success">
                        {{ session()->get('success') }}
                    </div>
                @endif
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <tr>
                                <th>Id</th>
                                <th>Name</th>
                                <th>Instructor email</th>
                                <th>Department</th>
                                <th>status</th>
                                <th>Image</th>
                                <th>Action</th>
                            </tr>
                            @foreach ($upcoming_course as $item)
                                <tr>
                                    <td>{{ $item->course_id }}</td>
                                    <td>{{ $item->name }}</td>
                                    <td>{{ $item->inst_email }}</td>
                                    <td>{{ $item->department }}</td>
                                    <td>{{ $item->status }}</td>
                                    <td>
                                        <img src="{{'/storage/'.$item->image}}" alt="image" style="width: 50px">
                                    </td>
                                    <td>
                                        <div class="btn-group" role="group" aria-label="Basic example">
                                            <form action="{{ route('course.destroy', $item->id) }}" method="POST">
                                                @csrf
                                                @method('DELETE')
                                                <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                                            </form>
                                          </div>
                                    </td>
                                </tr>  
                            @endforeach
                            
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
