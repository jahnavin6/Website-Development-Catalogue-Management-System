@extends('layouts.staff.layout')

@section('content')
    <div class="main-content about-main-content mt-5">
        <div class="container">
            <div class="card">
                <div class="card-header d-flex justify-content-between">
                    <h5 class="text-center">Add a course</h5>
                </div>
                <div class="card-body">
                    @if ($errors->any())
                        <div class="alert alert-danger">
                            <ul>
                                @foreach ($errors->all() as $error)
                                    <li>{{ $error }}</li>
                                @endforeach
                            </ul>
                        </div>
                    @endif
                    @if(session()->has('success'))
                        <div class="alert alert-success">
                            {{ session()->get('success') }}
                        </div>
                    @endif
                    @if(session()->has('failed'))
                        <div class="alert alert-success">
                            {{ session()->get('failed') }}
                        </div>
                    @endif
                 
                    <form action="{{ route('course.store') }}" method="POST" enctype="multipart/form-data">
                        @csrf
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label>Course name</label>
                                    <input type="text" class="form-control" name="name">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <label>Course id</label>
                                <input type="text" name="course_id" class="form-control">
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Select status</label>
                                    <select name="status" class="form-control">
                                        <option value="planned">Planned</option>
                                        <option value="upcoming">Upcoming</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <label>Department</label>
                                <input type="text" name="department" class="form-control">
                            </div>
                            <div class="col-md-6">
                             <div class="form-group">
                                <label>Instracture email</label>
                                <input type="text" name="inst_email" class="form-control">
                             </div>
                            </div>
                            <div class="col-md-12">
                             <div class="form-group">
                                <label>Image</label>
                                <input type="file" name="image" class="form-control">
                             </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group text-right">
                                    <button type="submit" class="btn btn-primary">Add course</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection

