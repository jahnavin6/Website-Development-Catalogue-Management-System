@extends('layouts.staff.layout')

@section('content')
    <div class="main-content about-main-content mt-5">
        <div class="container">
            <div class="card">
                <div class="card-header">
                    <h5 class="text-center">All feedback</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <tr>
                                <th>SI</th>
                                <th>Course name</th>
                                <th>Instractor email</th>
                                <th>Student name</th>
                                <th>Feedback</th>
                            </tr>
                            @php
                                $i=0;
                            @endphp
                            @foreach ($feedbacks as $item)
                            @php
                                $i++;
                            @endphp
                                <tr>
                                    <td>{{ $i }}</td>
                                    <td>{{ $item->course->name }}</td>
                                    <td>{{ $item->course->inst_email }}</td>
                                    <td>{{ $item->user->name }}</td>
                                    <td>{{ $item->feedback }}</td>
                                   
                                </tr>  
                            @endforeach
                            
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
