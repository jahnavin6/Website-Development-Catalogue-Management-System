@extends('layouts.frontend.layout')

@section('content')
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-4">
            <div class="card">
                <div class="card-header text-center"><h3>{{ __('Sign in') }}</h3></div>

                <div class="card-body">
                    @if(session()->has('failed'))
                    <div class="alert alert-info">
                        {{ session()->get('failed') }}
                    </div>
                @endif
                    {{-- <form method="POST" action="{{ route('login') }}"> --}}
                    <form method="POST" action="{{ route('custom_login') }}">
                        @csrf

                        <div class="form-group mt-4">
                            <input id="email" type="email" class="form-control @error('email') is-invalid @enderror" name="email" value="{{ old('email') }}" required autocomplete="email" autofocus placeholder="Email">

                        </div>

                        <div class="form-group">
                            <input id="password" type="password" class="form-control @error('password') is-invalid @enderror" name="password" required autocomplete="current-password" placeholder="Password">

                        </div>
                        <div class="form-group mb-0 mt-4">
                                <button type="submit" class="btn btn-primary btn-block">
                                    {{ __('Login') }}
                                </button>
                        </div>
                        
                        <div class="form-group text-center mt-3">
                            @if (Route::has('password.request'))
                            <a class="btn btn-link" href="{{ route('password.request') }}">
                                {{ __('Forgot Your Password?') }}
                            </a>
                        @endif
                    </div>
                    <div class="text-center">
                        <p>Don't have an account ? <a href="{{ route('register') }}">Sign up</a> </p>
                    </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
