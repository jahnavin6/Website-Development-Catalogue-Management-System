@extends('layouts.frontend.layout')

@section('content')
    <div class="main-content about-main-content mt-5">
        <div class="row justify-content-center">
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header text-center"><h3>{{ __('Give a feedback') }}</h3></div>
    
                    <div class="card-body">
                        @if ($errors->any())
                        <div class="alert alert-danger">
                            <ul>
                                @foreach ($errors->all() as $error)
                                    <li>{{ $error }}</li>
                                @endforeach
                            </ul>
                        </div>
                    @endif
                        @if(session()->has('success'))
                        <div class="alert alert-success">
                            {{ session()->get('success') }}
                        </div>
                    @endif
                    @if(session()->has('failed'))
                        <div class="alert alert-success">
                            {{ session()->get('failed') }}
                        </div>
                    @endif
                        <form method="POST" action="{{ route('feedback.store') }}">
                            @csrf
    
                            <div class="form-group">
                                <label>Select a course</label>
                                <select name="course_id" class="form-control">
                                    <option selected disabled>Select a course</option>
                                    @foreach ($enroll_courses as $item)
                                        <option value="{{ $item->course->id }}">{{ $item->course->name }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Feedback</label>
                                <textarea name="feedback" class="form-control" placeholder="Type your feedback here"></textarea>
                            </div>
                            <div class="form-group">
                                <button type="submit" class="btn btn-primary btn-block">Save</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection