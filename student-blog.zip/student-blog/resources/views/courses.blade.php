@extends('layouts.frontend.layout')

@section('content')
<div class="about-area">
    {{-- <div class="page-banner about-page-banenr">
        <h1 class="text-center">About</h1>
    </div> --}}
    <div class="main-content about-main-content mt-5">
        <div class="row">
            <div class="col-md-8 offset-md-2">
                <h3 class="mt-4">All courses</h3>
                <div class="home-department-list mt-5">
                    @if(session()->has('success'))
                    <div class="alert alert-success">
                        {{ session()->get('success') }}
                    </div>
                @endif
                @if(session()->has('failed'))
                    <div class="alert alert-success">
                        {{ session()->get('failed') }}
                    </div>
                @endif
                    <div class="row">
                        @foreach (\App\Course::orderBy('id', 'desc')->get() as $course)
                        <div class="col-md-4 mb-2">
                            <div class="single-department">
                                 <div class="card m-9 p-0">
                                     <div class="card-body m-0 p-0">
                                         <div class="department-image">
                                             <img src="{{'/storage/'.$course->image}}" alt="" width="100%">
                                         </div>
                                         <div class="department-content text-center pt-2 pb-2">
                                            <a href="" class="text-decoration-none">{{ $course->name }}</a>
                                            <div class="course-information-area text-left">
                                                <p><b>Department</b>  : {{ $course->department }}</p>
                                                <p><b>Ins. email</b>  : {{ $course->inst_email }}</p>
                                            </div>
                                                @php
                                                if(Auth::check()) {
                                                    $check_enrole = \App\Enroll::where('course_id', $course->id)->where('user_id',Auth::user()->id)->count();
                                                }else {
                                                    $check_enrole = 0;
                                                }
                                                    
                                                @endphp
                                           
                                             @if($check_enrole > 0)
                                            
                                                <button class="btn btn-danger btn-block" disabled>Already enroled</button>
                                                @else
                                                <a href="{{ route('course.enrole', $course->id) }}" class="btn btn-primary btn-block mt-2">Enroll</a>
                                             @endif
                                         </div>
                                     </div>
                                 </div>
                            </div>
                         </div> 
                        @endforeach
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
