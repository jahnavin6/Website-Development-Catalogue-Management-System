@extends('layouts.frontend.layout')
<link rel="stylesheet" href="{{ asset('frontend/css/chat.css') }}">
<!------ Include the above in your HEAD tag ---------->

@section('content')
<div class="container mt-3">
    <div class="row">
          <div class="col-md-8 mx-auto">
              <div class="card">
                  <div class="card-header text-center">
                      <span>Chat with {{ $receiver_user->name }}</span>
                  </div>
                  <div class="card-body chat-body chat-care">
                      <ul class="chat">

                          @if($chat)
                          @foreach (\App\ChatMessage::where('chat_id', $chat->id)->get() as $chatmessage)
                          @php
                              $sender = \App\User::where('id', $chatmessage->sender_id)->first();
                              $receiver = \App\User::where('id', $chatmessage->reciver_id)->first();
                          @endphp
                          @if($chatmessage->sender_id == Auth::user()->id)
                          <li class="admin clearfix">
                            <span class="chat-img right clearfix  mx-2">
                                <img src="http://placehold.it/50/FA6F57/fff&text=ME" alt="Admin" class="img-circle" />
                            </span>
                            <div class="chat-body clearfix">
                                <div class="header clearfix">
                                    <small class="left text-muted"><span class="glyphicon glyphicon-time"></span>{{ Carbon\Carbon::parse($chatmessage->created_at)->diffForHumans()}} 
                                    </small>
                                    <strong class="right primary-font">{{ $sender->name }}</strong>
                                </div>
                                <p>
                                    {{ $chatmessage->message }}
                                </p>
                            </div>
                        </li>
                            @else 
                            <li class="agent clearfix">
                                <span class="chat-img left clearfix mx-2">
                                    <img src="http://placehold.it/50/55C1E7/fff&text=U" alt="Agent" class="img-circle" />
                                </span>
                                <div class="chat-body clearfix">
                                    <div class="header clearfix">
                                        <strong class="primary-font">{{ $receiver->name }}</strong> <small class="right text-muted">
                                            <span class="glyphicon glyphicon-time"></span>{{ Carbon\Carbon::parse($chatmessage->created_at)->diffForHumans()}} </small>
                                    </div>
                                    <p>
                                        {{ $chatmessage->message }}
                                    </p>
                                </div>
                            </li>
                            @endif
                          @endforeach
                          @endif
                         
                         
                      </ul>
                  </div>
                  <div class="card-footer">
                      <form action="{{ route('chat.store') }}" method="POST">
                        @csrf
                        <div class="input-group">
                            <input id="btn-input" type="text" name="message" class="form-control input-sm" placeholder="Type your message here..." />
                            <input type="hidden" name="reciver_id" value="{{ $receiver_user->id }}">
                            <span class="input-group-btn">
                                <button type="submit" class="btn btn-primary" id="btn-chat">
                                    Send</button>
                            </span>
                        </div>
                      </form>
                  </div>
              </div>
          </div>
      </div>
  </div>



@endsection


@section('frontend_script')
<script>
    $('.chat-body').scrollTop(1000000);
</script>    
@endsection