@extends('layouts.frontend.layout')

@section('content')
<div class="about-area">
    <div class="page-banner about-page-banenr">
        <h1 class="text-center">About</h1>
    </div>
    <div class="main-content about-main-content text-center mt-5">
        <div class="container">
            <h3 class="m-4">SUCCEED BY SAVING TIME </h3>
            <p>At CMS, we believe that learning is the world's most powerful force for change.The platform helps students, faculty to save time, increase productivity among everything.
            </p>
            <p>
                Developed in such a way that student will be able to select the courses from the given list and enroll.
            </p>
            <h3 class="m-4">STUDY.ACHIEVE.EXCEL
            </h3>
        </div>
    </div>
</div>
@endsection
