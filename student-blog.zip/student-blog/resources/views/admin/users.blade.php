@extends('layouts.admin.layout')

@section('content')
    <div class="main-content about-main-content mt-5">
        <div class="container">
            <div class="card">
                <div class="card-header">
                    <h5 class="text-center">All users</h5>
                </div>
                <div class="card-body">
                    @if(session()->has('success'))
                    <div class="alert alert-success">
                        {{ session()->get('success') }}
                    </div>
                @endif
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <tr>
                                <th>Sl</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>User type</th>
                                <th>Action</th>
                            </tr>
                            @php
                                $i=0;
                            @endphp
                            @foreach ($users as $user)
                            @php
                                $i++;
                            @endphp
                                <tr>
                                    <td>{{ $i }}</td>
                                    <td>{{ $user->name }}</td>
                                    <td>{{ $user->email }}</td>
                                    <td>{{ $user->role }}</td>
                                    <td>
                                        <a href="{{ route('admin.delete.users',$user->id) }}" class="btn btn-danger btn-sm">Delete</a>
                                    </td>
                                </tr>  
                            @endforeach
                            
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
