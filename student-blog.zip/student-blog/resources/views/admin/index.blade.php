@extends('layouts.admin.layout')

@section('content')
<div class="about-area">
    {{-- <div class="page-banner about-page-banenr">
        <h1 class="text-center">About</h1>
    </div> --}}
    <div class="main-content about-main-content mt-5">
        <div class="row">
            <div class="col-md-8 offset-md-2">
                <h3 class="bg-info p-3 text-center">Admin dashboard</h3>
                <div class="content">
                    <h3>CATALOGUE MANAGEMENT SYSTEM</h3>
                    <p>Welcome to the CMS page, a one stop place to have a look at the courses. CMS is a dedicated platform for students where they'll be able to easily enroll for classes.</p>
                </div>
                <div class="home-department-list mt-5">
                    <h5 class="pb-3">Department-list</h5>
                    <div class="row">
                        <div class="col-md-3">
                           <div class="single-department">
                                <div class="card m-9 p-0">
                                    <div class="card-body m-0 p-0">
                                        <div class="department-image">
                                            <img src="{{ asset('frontend/images/department/cs.jpg') }}" alt="" width="100%">
                                        </div>
                                        <div class="department-content text-center pt-2 pb-2">
                                            <a href="javascript:void(0)" class="text-decoration-none">Computer science</a>
                                        </div>
                                    </div>
                                </div>
                           </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
