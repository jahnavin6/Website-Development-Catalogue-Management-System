<?php

use Illuminate\Support\Facades\Route;


Route::get('/', 'FrontendController@index')->name('home_page');

Auth::routes();

Route::post('custom-login', 'AuthController@login')->name('custom_login');


Route::get('/home', function(){
    return redirect()->to('/');
})->name('home');

Route::get('about', 'FrontendController@about')->name('about');


Route::group(['middleware' => ['auth', 'admin'], 'prefix' => 'admin'], function () {
    Route::get('/', 'AdminController@index')->name('admin.home');
    Route::get('/about', 'FrontendController@admin_about')->name('admin_about');
    Route::get('/users', 'AdminController@users')->name('admin.users');
    Route::get('users/delete/{id}', 'AdminController@delete_user')->name('admin.delete.users');
});

Route::group(['middleware' => ['auth', 'student'], 'prefix' => 'student'], function () {
    Route::get('/', 'StudentController@index')->name('student.home');
    Route::get('courses/enrole/{id}', 'StudentController@enroll_courses')->name('course.enrole');
    Route::get('enroll/courses/', 'StudentController@enrolled_course')->name('enrolled_course');
    Route::get('provide/feedback', 'StudentController@provide_feedback')->name('provide_feedback');
    Route::post('feedback/store', 'FeedbackController@store')->name('feedback.store');
    Route::get('teacher/list', 'StudentController@tacher_list')->name('teacher.list');
    Route::get('student/about', 'FrontendController@student_about')->name('student_about');
    Route::get('courses', 'StudentController@courses')->name('all.course');
});
Route::group(['middleware' => ['auth', 'staff'], 'prefix' => 'staff'], function () {
    Route::get('/', 'StaffController@index')->name('staff.home');
    Route::get('/about', 'FrontendController@staff_about')->name('staff_about');
    Route::resource('/course', 'CourseController');
    Route::get('/planned/course', 'CourseController@planned_course')->name('staff.planned_course');
    Route::get('/upcoming/course', 'CourseController@upcoming_course')->name('staff.upcoming_course');
    Route::get('/view/feedback', 'FeedbackController@index')->name('staff.feedback');
    Route::get('student/list', 'StaffController@student_list')->name('student.list');
});

Route::group(['middleware' => ['auth']], function () {
    Route::get('chat/{id}', 'ChatController@create')->name('single.chat');
    Route::post('chat/store', 'ChatMessageController@store')->name('chat.store');
});
