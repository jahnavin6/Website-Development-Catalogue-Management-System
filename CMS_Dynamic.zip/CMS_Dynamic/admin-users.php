<?php
    session_start();
    $name=$_SESSION['user'];
	$servername = @"localhost";
/*Provide respective detauls for username, pwd, dbname and port*/
	$username = "#";
	$password = "#";
	$dbname = "#";
	$port = "#";

	$conn =  mysqli_connect($servername, $username, $password, $dbname, $port);

	if (mysqli_connect_errno()) 
    {
	    echo "DB Error oocured ".mysqli_connect_errno();
	}
?>

<html>
<head>
    <title>Admin - Users Page</title>
     <meta name="viewport" content="width=device-width,initial-scale=1">
    <link rel="stylesheet" href="cataloguesystem.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    </head>
    <body>
    <div class="main-bar">
        <div class="home-nav-bar">
                
            <div class="home-nav-links">
                <div class="dropdown1"
style="float:right;">
                    <div class="home-nav-logo">
        <img src="images/student.png">
        </div>

                    <button class="dropbtn1"><a href="mainhomepage.html">Signout</a></button>

</div>
               <ul>
                <a href="admin-homepage.html"><li>Home</li></a>
                <a href="about-admin.html"><li>About</li></a>
                <a href="https://jxn7251.uta.cloud/" target="_blank"><li>Forum</li></a>
                    <a href="admin-users.php"><li>Users</li></a>

                </ul>
                <button type="button" class="home-btn">
                    <a href="signup.html">SIGN UP</a></button> &nbsp;&nbsp;
                <button type="button" class="home-btn"> <a href="login.html">Login</a></button>
            </div>
        </div>
       <div class="wrapper">
            <div class="home-banner-title">
                <div class="font-color"><h2>User Details</h2></div>
            <br>

        </div>
            
           
            
           <div class="wrapper"><div class="responsive-body">
  <div class="font-color"><table id="myTable" >
      <div class="font-color"><tr class="tableheader">
    
      <th style="width:35%;"><div class="font-color">User Name</div></th>
     <div class="font-color"> <th style="width:20%;">Email</th></div>
         <div class="font-color"> <th style="width:38%;">Role</th></div>
         <div class="font-color"><th style="width:7%;"></th></div>
    </tr>
     </div>
    <?php
        $sql = "SELECT  name, email, role FROM users";
         $result = $conn->query($sql);
        while($row = $result->fetch_assoc()) {
           echo "<tr>";
             
              echo  "<td>$row[name]</td>";
              echo  "<td>$row[email]</td>";
              echo  "<td>$row[role]</td>";
               echo "<td><a href='https://jxn7251.uta.cloud/nuthalapati_phase4/deleteadmin.php?id=".$row['email']."'>Delete</a></td>";
            echo "</tr>";
        }
    ?>
</table>
               </div>
        &nbsp;&nbsp;
        
           
                <button type="button" class="home-btn" name="addcourse" onclick="window.location.href='https://jxn7251.uta.cloud/nuthalapati_phase4/addauser.php'">
                    Add User</button> 
        
                
        <br><br>
               </div></div>
           
           
           
        </div>

        
        
        
        
        </div>
    

        
    </body>
    <br><br><br><br><br><br>
    <div class="bottom-footer">
    <div class="footer-innercontent">
        <div class="section-footer"></div>
        <div class="section-footer-links"></div>
        <div class="section-footer contact-form"></div>
        
    </div>
    <div class="down-footer">
        <i class="fa fa-instagram"></i>&nbsp; <i class="fa fa-facebook"></i>&nbsp; <i class="fa fa-reddit"></i>&nbsp; <i class="fa fa-youtube"></i>&nbsp; <i class="fa fa-twitter"></i> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &copy; Copyrights reserved | Designed by Jahnavi Nuthalapati
    </div>
    </div>
</html>