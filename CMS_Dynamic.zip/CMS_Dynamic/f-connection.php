<?php  
    

	$servername = @"localhost";
/*Provide respective detauls for username, pwd, dbname and port*/
	$username = "#";
	$password = "#";
	$dbname = "#";
	$port = "#";
$conn = mysqli_connect($sname, $uname, $password, $dbname,$port);

if (mysqli_connect_errno()) {
	    echo "DB connection failed. ".mysqli_connect_errno();
	}
?>