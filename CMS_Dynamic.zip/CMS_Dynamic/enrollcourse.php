<?php  

session_start();    
    $name=$_SESSION['user'];
	
	$servername = @"localhost";
/*Provide respective detauls for username, pwd, dbname and port*/
	$username = "#";
	$password = "#";
	$dbname = "#";
	$port = "#";

$conn = mysqli_connect($servername, $username, $password, $dbname, $port);

if (mysqli_connect_errno()) {    
    echo "DB Error oocured ".mysqli_connect_errno();
}
$id = $_GET['id'];
$mail = $_GET['mail'];
mysqli_query($conn,"INSERT INTO enroll(coursename,inst_email,email) VALUES('$id','$mail','".$name."')");
mysqli_close($conn);
header("Location: https://jxn7251.uta.cloud/nuthalapati_phase4/listofcourses.php");

?>
