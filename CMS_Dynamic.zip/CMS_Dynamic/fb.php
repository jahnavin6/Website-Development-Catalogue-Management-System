<?php


	$servername = @"localhost";
/*Provide respective detauls for username, pwd, dbname and port*/
	$username = "#";
	$password = "#";
	$dbname = "#";
	$port = "#";
	
	$conn =  mysqli_connect($servername, $username, $password, $dbname, $port);

	if (mysqli_connect_errno()) {
	    echo "DB Error oocured. ".mysqli_connect_errno();
	}

	if(isset($_POST['submit'])){

		$email=$_POST['email'];
		$name=$_POST['name'];
		$message=$_POST['message'];
    
			$insertQuery = "INSERT INTO feedback(email, name, message) VALUES ('$email', '$name', '$message')";
			if(mysqli_query($conn, $insertQuery)){
                $to = $_POST['email']; 
   				$from = "edurandomacc@gmail.com";
    			$name = $_POST['subject'];
    			
    			
     
    			$subject = "Feedback";
    
    			$fmail ="Feedback From Students."."\n"."" . $message . "";
   

    			$headers = "From:" . $from;
   				mail($to,$subject,$fmail,$headers);
 
				echo "<h1>Your feedback is valuable to us. You have successfully provided your feedback. You may now close the browser.</h1>";
			}
			else{
				echo "<center><h1>We regret there was a problem. Kindly refresh the page then come back</h1></center>";
			}


}
    
$conn->close();
?>