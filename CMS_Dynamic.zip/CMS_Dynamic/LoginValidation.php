<?php
    session_start();
	$servername = @"localhost";
/*Provide respective detauls for username, pwd, dbname and port*/
	$username = "#";
	$password = "#";
	$dbname = "#";
	$port = "#";

	$conn =  mysqli_connect($servername, $username, $password, $dbname, $port);

	if (mysqli_connect_errno()) 
    {
	    echo "DB connection failed! ".mysqli_connect_errno();
	}

	if(isset($_POST['login'])){
		$name=$_POST['uname'];
		$password=$_POST['pword'];

		if(!isset($name)){
			echo "Please enter your email!";
		}
		else if(!isset($password)){
			echo "Please enter your password!";
		}
		
		$querycheck = "SELECT email,password,role FROM users WHERE email='$name' AND password='$password'";
		$disp=mysqli_query($conn, $querycheck);
		$user_c  = mysqli_num_rows($disp);
		if($user_c==0) {
			echo '<script>alert("Kindly re-check your credentials!")</script>' ; 
		} 
		else {
			$user_login = mysqli_fetch_assoc($disp);
			
            if ($user_login['role'] == 'student') 
            {
			    $_SESSION['user'] = $name;
                header('Location: https://jxn7251.uta.cloud/nuthalapati_phase4/student-homepage.html');
			}
            elseif ($user_login['role'] == 'admin') 
            {
			    $_SESSION['user'] = $name;
				header('Location: https://jxn7251.uta.cloud/nuthalapati_phase4/admin-homepage.html');
                
            }
             elseif ($user_login['role'] == 'staff') 
             {
			    $_SESSION['user'] = $name;
				header('Location: https://jxn7251.uta.cloud/nuthalapati_phase4/staff-homepage.html');
                
            }
            
			else{
				$_SESSION['user'] = $user_login;
				header('Location: https://jxn7251.uta.cloud/nuthalapati_phase4/mainhomepage.html');
			}
			
		}
	}
?>