<?php

	$servername = @"localhost";
/*Provide respective detauls for username, pwd, dbname and port*/
	$username = "#";
	$password = "#";
	$dbname = "#";
	$port = "#";
	
	$conn =  mysqli_connect($servername, $username, $password, $dbname, $port);

	if (mysqli_connect_errno()) {
	    echo "DB connection failed. ".mysqli_connect_errno();
	}

	if(isset($_POST['s-submit'])){

		$name=$_POST['fullname'];
		$email=$_POST['fmail'];
		$password=$_POST['pword'];
		$confirmpass=$_POST['confirmpword'];
        $role=$_POST['role'];

		$email_check='/^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$/';
			$pass_check='/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,}$/';

		if(!isset($name)){
			echo "<p>Kinly enter a valid name</p>";
		}
	
		else if(!isset($email) || !preg_match($email_check,$email)){
			echo "<p>Kindly re-check your email.</p>";
		}
		
		else if(!isset($password) || !preg_match($pass_check, $password)){
			echo "<p>Minimum 6 characters required</p>";
		}
		else if(!isset($confirmpass) || ($password != $confirmpass)){
			echo "<p>Both the password fields should mact!</p>";
		}
		else{
			$insertQuery = "INSERT INTO users(name, email, password, role) VALUES ('$name', '$email', '$password','$role')";
			if(mysqli_query($conn, $insertQuery)){
				echo "<h1>You have successfully registered! Kindly check your email for the conformation. You may now close the browser and go to login page.</h1>";
			}
			else{
				echo "<center><h1>We regret there was a problem. Kindly refresh the page then come back</h1></center>";
			}
            if(mysqli_query($conn, $insertQuery)){
				$to = $_POST['fmail']; // this is your Email address
   				$from = "edurandomacc@gmail.com"; // this is the sender's Email address
    			$name1 = $_POST['fullname'];
    			$mail1 = $_POST['fmail'];
    			$password1 = $_POST['pword'];
    
    			$subject = "Registration Successful || Your Account Details";
    
    			$message ="Thank you for your registration. Here is a copy of your submission." . "\n Name:" . $name1 . "\n Email: " . $mail1 . "\n Password:" . $password1 ;
   

    			$headers = "From:" . $from;
   				mail($to,$subject,$message,$headers);
 
    			echo "Sent the Mail. Thank you " . $name1 . ", will get back to you asap.";
			}
			else{
				echo "<center><h1>We regret that there was a problem. Kindly refresh the page then come back</h1></center>";
			}
		}
	}

	$conn->close();

?>
