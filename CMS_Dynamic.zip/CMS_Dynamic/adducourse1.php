<?php

session_start();
    $name=$_SESSION['user'];
	
	$servername = @"localhost";
/*Provide respective detauls for username, pwd, dbname and port*/
	$username = "#";
	$password = "#";
	$dbname = "#";
	$port = "#";

$conn = mysqli_connect($servername, $username, $password, $dbname, $port);

if (mysqli_connect_errno()) {
    echo "DB Error oocured ".mysqli_connect_errno();
}
$courseid = $_POST['courseid'];
$coursename = $_POST['coursename'];
$dept = $_POST['dept'];
$status = $_POST['status'];
    
    
mysqli_query($conn,"INSERT INTO courses_list VALUES('$courseid','$coursename','$name','$dept','$status')" );
mysqli_close($conn);
header("Location: https://jxn7251.uta.cloud/nuthalapati_phase4/upcomingcourses.php");

?>
