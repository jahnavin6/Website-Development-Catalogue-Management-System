<html>
     <head>
    <title>Add Courses</title>
   <meta name="viewport" content="width=device-width,initial-scale=1">
    <link rel="stylesheet" href="cataloguesystem.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    </head>
    <body>
        <div class="container">
  <div class="topleft">
            <div class="dropdown"
style="float:inherit;">
<button class="dropbtn">Go to</button>

  <div class="dropdown-content"
  style="left:0;">
    <a href="staff-homepage.html">HOME</a>
      <a href="about-staff.html">About</a>
  </div>
    
    </div>
            </div>
            
</div>
      <div class="wrapper"> 
     <div class="sign-up-form">
        <img src="images/usericon.png">
       <br><br> <h1>Add Courses</h1>  
         
         <form action="adducourse1.php" form class="box" id="signupform" method="POST" name="signupform">
    
             <input id="fullname" class="input-box" type="text" placeholder="Enter your course id" name="courseid" required oninvalid="this.setCustomValidity('Please enter your message')" oninput="this.setCustomValidity('')">
        
    <input id="fmail" class="input-box" type="text" placeholder="Your coursename" name="coursename" required oninvalid="this.setCustomValidity('Please enter your message')" oninput="this.setCustomValidity('')">
    
             <input id="pword" class="input-box" type="text" placeholder="Enter Instructor email" name="dept" required oninvalid="this.setCustomValidity('Please enter your password')" oninput="this.setCustomValidity('')">
    
            
              <label>Select Status</label>
            <select name="status" class="required" required oninvalid="this.setCustomValidity('Please select your role')" oninput="this.setCustomValidity('')">
                
                <option>Planned</option>
                <option>Upcoming</option>
                
            </select>
    <button type="submit" class="signup-btn" name="s-submit" onclick="user_type()">Add course</button>
         </form>
    
            <br><br><br>
            <hr>
            <p class="or">OR</p>
            <p>Already have an Account?
                <a href="login.html">Login</a></p>
        </div>
        </div>
    </body>
    <script>
    
    </script>
    <div class="bottom-footer">
    <div class="footer-innercontent">
        <div class="section-footer"></div>
        <div class="section-footer-links"></div>
        <div class="section-footer contact-form"></div>
        
    </div>
        <br><br><br><br><br><br>
    <div class="down-footer">
        <i class="fa fa-instagram"></i>&nbsp; <i class="fa fa-facebook"></i>&nbsp; <i class="fa fa-reddit"></i>&nbsp; <i class="fa fa-youtube"></i>&nbsp; <i class="fa fa-twitter"></i> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &copy; Copyrights reserved | Designed by Jahnavi Nuthalapati
    </div>
    </div>
</html>