<?php
    session_start();
    $name=$_SESSION['user'];
	
	$servername = @"localhost";
/*Provide respective detauls for username, pwd, dbname and port*/
	$username = "#";
	$password = "#";
	$dbname = "#";
	$port = "#";

	$conn =  mysqli_connect($servername, $username, $password, $dbname, $port);

	if (mysqli_connect_errno()) 
    {
	    echo "Error DB inconsistent connection! ".mysqli_connect_errno();
	}
?>

<html>
<head>
    <title>List of Courses</title>
     <meta name="viewport" content="width=device-width,initial-scale=1">
    <link rel="stylesheet" href="cataloguesystem.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    </head>
    <body>
    <div class="main-bar">
        <div class="home-nav-bar">
                
            <div class="home-nav-links">
                <div class="dropdown1"
style="float:right;">
                    <div class="home-nav-logo">
        <img src="images/student.png">
        </div>

                    <button class="dropbtn1"><a href="mainhomepage.html">Signout</a></button>

</div>
              <ul>
                <a href="student-homepage.html"><li>Home</li></a>
                <a href="about-student.html"><li>About</li></a>
                <a href="https://jxn7251.uta.cloud/" target="_blank"><li>Forum</li></a>
                    <a href="providefeedback.html" target="_blank"><li>Provide Feedback</li></a>
                <a href="faq-student.html"><li>FAQs</li></a>
                 <a href="contactv.php" target="_blank"><li>Contact Us</li></a>
                <a href="listofcourses.php"><li>List of Courses</li></a>
                <a href="show-enrolled.php"><li>Enrolled Courses</li></a>
                <a href="courseguidance-student.html"><li>Course Guidance</li></a>
                </ul>
                <button type="button" class="home-btn">
                    <a href="signup.html">SIGN Up</a></button> &nbsp;&nbsp;
                <button type="button" class="home-btn"> <a href="login.html">Login</a></button>
            </div>
        </div>
       <div class="wrapper">
            <div class="home-banner-title">
                <div class="font-color"><h2>List of Courses</h2></div>
            <br>

        </div>
           
            <div class="home-banner-title">
                <div class="font-color"><p>Given below are the list of courses which help you to enroll. So check the course requirements and kindly enter "enroll" button.</p></div>
            <br>

        </div>
            
           
            
           <div class="wrapper"><div class="responsive-body">
  <div class="font-color"><table id="myTable" >
      <div class="font-color"><tr class="tableheader">
    
      <th style="width:35%;"><div class="font-color">Course Name</div></th>
     <div class="font-color"> <th style="width:20%;">Department</th></div>
         <div class="font-color"> <th style="width:38%;">Instructor Email</th></div>
         <div class="font-color"><th style="width:7%;"></th></div>
    </tr>
     </div>
    <?php
        $sql = "SELECT  * FROM courses_list WHERE course_status='planned'";
         $result = $conn->query($sql);
        while($row = $result->fetch_assoc()) {
           echo "<tr>";
             
              echo  "<td>$row[course_name]</td>";
              echo  "<td>$row[course_id]</td>";
              echo  "<td>$row[inst_email]</td>";
              echo "<td><a href='https://jxn7251.uta.cloud/nuthalapati_phase4/enrollcourse.php?id=".$row['course_name']." &mail=".$row['inst_email']."'>Enroll</a></td>";
            echo "</tr>";
        }
    ?>
</table>
               </div>
        &nbsp;&nbsp;
        
           
    
        
                
        
               </div></div>
           
           
           
        </div>

        
        
        
        
        </div>
    

        
    </body>
    <br><br><br><br><br><br>
    <div class="bottom-footer">
    <div class="footer-innercontent">
        <div class="section-footer"></div>
        <div class="section-footer-links"></div>
        <div class="section-footer contact-form"></div>
        
    </div>
    <div class="down-footer">
        <i class="fa fa-instagram"></i>&nbsp; <i class="fa fa-facebook"></i>&nbsp; <i class="fa fa-reddit"></i>&nbsp; <i class="fa fa-youtube"></i>&nbsp; <i class="fa fa-twitter"></i> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &copy; Copyrights reserved | Designed by Jahnavi Nuthalapati
    </div>
    </div>
</html>