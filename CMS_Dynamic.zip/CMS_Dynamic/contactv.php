<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="bootstrap.css">
     <link rel="stylesheet" href="cataloguesystem.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/css/all.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Contact Us Form</title>
</head>
    
    <body>

   
        <div class="des"><h2> Contact Us </h2></div>
                        <hr>
                        <?php 
                            $Msg = "";
                            if(isset($_GET['error']))
                            {
                                $Msg = "Kindly please fill in the fields";
                                echo '<div class="alert alert-danger">'.$Msg.'</div>';
                            }

                            if(isset($_GET['success']))
                            {
                                $Msg = "Success!! Your Form has been submitted! Please allow 2 business days to get back to you.";
                                echo '<div class="alert alert-success">'.$Msg.'</div>';
                            }
                        
                        ?>
                    
                  <div class="wrapper">
        
            <div class="home-banner-title">
                <div class="font-color"><h2>CONTACT US</h2></div>
            <br>
  <div class="body-contact">
    <div class="contact-us">
        <div class="contactus-card">
        <i class="contactcard-icon far fa-envelope"></i>
            
            <p>email@exampledomain.com</p>
        </div>
         
        <div class="contactus-card">
        <i class="contactcard-icon far fa-phone"></i>
           
            <p>+1 (000) 000 0000</p>
        </div>
         
        <div class="contactus-card">
        <i class="contactcard-icon far fa-map-marker-alt"></i>
            <p>Arlington, TX - USA</p>
        </div>
        </div>
    </div>
        </div>
                      <div class="resp"><div class="wrapper"><div class="font-color"><h2>CONTACT US FORM</h2></div></div></div>
                      <div class="wrapper"><div class="responsive-body">
        <div class="resp">
                        <form action="contactus-validation.php" method="post">
                            <input type="text" name="UName" id="UName" placeholder="User Name" class="input-box" required oninvalid="this.setCustomValidity('Please enter your name')" oninput="this.setCustomValidity('')">
                            <br><br>
                            <input type="email" name="Email" id="Email" placeholder="Email" class="input-box" required oninvalid="this.setCustomValidity('Please enter your email')" oninput="this.setCustomValidity('')">
                            <br><br>
                            <input type="text" name="Subject" id="Subject" placeholder="Subject" class="input-box" required oninvalid="this.setCustomValidity('Please enter ythe subject')" oninput="this.setCustomValidity('')">
                            <br><br>
                            <textarea name="msg" class="input-box" id="msg" placeholder="Write The Message" required oninvalid="this.setCustomValidity('Please enter your message')" oninput="this.setCustomValidity('')"></textarea>
                            <br><br>
                            <button class="signin-btn" name="btn-send" onclick="validate-contact()">Send Form </button>
                        </form>
            <br><br><br><br><br>
                    </div></div></div></div>
        
        <script type="text/javascript">
    function validate_contact()
        {
            var UName = document.getElementById('UName').value;
             var Email = document.getElementById('Email').value;
            var Subject = document.getElementById('Subject').value;
             var msg = document.getElementById('msg').value;
             var error_message = document.getElementById('error_message').value;
             var t;
            
             if(UName.length<2)
                 {
                     t = "Please enter a valid name!"
                     error_message.innerHTML = t;
                     return false;
                 }
            
            if(Email.indexOf('@') == -1 || Email.length < 6)
                 {
                     t = "Please enter a valid email!"
                     error_message.innerHTML = t;
                     return false;
                 }
            
            
            if(Subject.length<2)
                 {
                     t = "Please enter a valid subject!"
                     error_message.innerHTML = t;
                     return false;
                 }
            
            if(msg.length<50)
                 {
                     t = "Please enter a message greater than 50 characters!"
                     error_message.innerHTML = t;
                     return false;
                 }
            
            alert("Form submitted successfully")
            return true;
        }
        </script>
    <div class="bottom-footer">
    <div class="footer-innercontent">
        <div class="section-footer"></div>
        <div class="section-footer-links"></div>
        <div class="section-footer contact-form"></div>
        
    </div>
    <div class="down-footer">
        <i class="fa fa-instagram"></i>&nbsp; <i class="fa fa-facebook"></i>&nbsp; <i class="fa fa-reddit"></i>&nbsp; <i class="fa fa-youtube"></i>&nbsp; <i class="fa fa-twitter"></i> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &copy; Copyrights reserved | Designed by Jahnavi Nuthalapati
    </div>
    </div>
                
</body>
</html>