<?php 
	
	$servername = @"localhost";
/*Provide respective detauls for username, pwd, dbname and port*/
	$username = "#";
	$password = "#";
	$dbname = "#";
	$port = "#";

	$conn =  mysqli_connect($servername, $username, $password, $dbname, $port);

	if (mysqli_connect_errno()) 
    {
	    echo "Error DB inconsistent connection! ".mysqli_connect_errno();
	}
    if(isset($_POST['btn-send']))
    {
       $UserName = $_POST['UName'];
       $Email = $_POST['Email'];
       $Subject = $_POST['Subject'];
       $Msg = $_POST['msg'];

       if(empty($UserName) || empty($Email) || empty($Subject) || empty($Msg))
       {
           header('location:contactv.php?error');
       }
       else
       {
           $to = "edurandomacc@gmail.com";

           if(mail($to,$Subject,$Msg,$Email))
           {
               header("location:contactv.php?success");
           }
       }
    }
    else
    {
        header("location:contactv.php");
    }
?>
