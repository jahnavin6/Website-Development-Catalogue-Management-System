<?php

session_start();
    $name=$_SESSION['user'];
	
	$servername = @"localhost";
/*Provide respective detauls for username, pwd, dbname and port*/
	$username = "#";
	$password = "#";
	$dbname = "#";
	$port = "#";
$conn = mysqli_connect($servername, $username, $password, $dbname, $port);

if (mysqli_connect_errno()) {
    echo "DB Error oocured ".mysqli_connect_errno();
}
$id = $_GET['id'];
mysqli_query($conn,"DELETE FROM courses_list WHERE course_id='".$id."' AND inst_email ='".$name."'");
mysqli_close($conn);
header("Location: https://jxn7251.uta.cloud/nuthalapati_phase4/upcomingcourses.php");

?>
